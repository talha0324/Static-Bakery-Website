$(function() {
  
  // var adScript = document.createElement("script");
  // adScript.type = "text/javascript";
  // adScript.src = "https://s.yimg.com/lm/hosting-ui/js/ysbbanner.js";
  // $("body").append(adScript);
});
